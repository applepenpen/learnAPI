import pdb
import platform
from typing import Optional

import requests
from selenium import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.common.options import ArgOptions as ArgOptions
from selenium.webdriver.firefox.service import Service as FirefoxService
from selenium.webdriver.ie.service import Service as IEService
from selenium.webdriver.remote.webdriver import WebDriver
from webdriver_manager.chrome import ChromeDriverManager
from webdriver_manager.firefox import GeckoDriver, GeckoDriverManager
from webdriver_manager.microsoft import IEDriverManager

__all__ = ["debugger", "get_webdriver"]
import logging

wdm_logger = logging.getLogger("WDM")
wdm_logger.setLevel(logging.ERROR)


def get_geckodriver_manager():
    def _geckodriver_get_url(self) -> str:
        base_url = "https://registry.npmmirror.com/-/binary/geckodriver"
        name = (
            f"{self.get_name()}-{self.get_version()}-{self.get_os_type()}{'-aarch64' if (self.get_os_type() == 'macos' and not platform.processor() == 'i386') else ''}"
            + ".zip"
        )
        url = f"{base_url}/{self.get_version()}/{name}"
        return url

    GeckoDriver.get_url = _geckodriver_get_url

    return GeckoDriverManager()


def get_chrome_manager(version):
    latest_release_url = (
        "https://registry.npmmirror.com/-/binary/chromedriver/LATEST_RELEASE"
    )
    if version:
        version = requests.get(latest_release_url + "_" + str(version)).text
    else:
        version = "latest"

    return ChromeDriverManager(
        version=version,
        url="https://registry.npmmirror.com/-/binary/chromedriver",
        latest_release_url=latest_release_url,
    )


def get_webdriver(
    browser="chrome",
    version=None,
    options: Optional[ArgOptions] = None,
    service_args: dict = None,
) -> WebDriver:
    """
    自动就绪selenium，目前只支持Chrome 和 FireFox
    1. 下载浏览器驱动
    2. 实例化Service
    3. 实例化WebDriver
    :param browser: 浏览器类型
    :param version: 浏览器版本
    :param options: 浏览器选项
    :param service_args: service 实例化的参数
    :return:
    """

    service_args = service_args or {}
    browser = browser.lower()
    if browser == "chrome":
        _path = get_chrome_manager(version=version).install()
        service_args.update(executable_path=_path)
        return webdriver.Chrome(
            service=ChromeService(**service_args),
            options=options,
        )

    elif browser == "firefox":
        _path = get_geckodriver_manager().install()
        service_args.update(executable_path=_path)
        return webdriver.Firefox(
            service=FirefoxService(**service_args),
            options=options,
        )

    elif browser == "ie":
        _path = IEDriverManager().install()
        service_args.update(executable_path=_path)
        return webdriver.Ie(
            service=IEService(**service_args),
            options=options,
        )


def debugger(driver, vars_dic: dict):
    """
    进入调试模式，为浏览器和python设置断言
    :param driver: WebDriver实例
    :param vars_dic: 需要使用据局部变量
    :return:
    """
    locals_vars = locals()
    locals_vars.update(vars_dic)  # 设置局部变量，以便直接调试

    driver.execute_cdp_cmd("Debugger.enable", {})
    driver.execute_script("setTimeout('debugger', 0.1 * 1000)")
    pdb.set_trace()
    driver.execute_cdp_cmd("Debugger.disable", {})
