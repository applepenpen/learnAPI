import logging
import time
from pathlib import Path
from typing import List, Optional

from selenium.common.exceptions import StaleElementReferenceException, TimeoutException
from selenium.webdriver.chrome.webdriver import WebDriver
from selenium.webdriver.common.alert import Alert
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support.expected_conditions import url_changes
from selenium.webdriver.support.wait import WebDriverWait

logger = logging.getLogger(__name__)


class BaseLazy:
    driver: Optional[WebDriver] = None
    _attrs: tuple
    _origin_class: None

    def __repr__(self):
        s_attrs = ""
        for attr in self._attrs:
            if attr == "driver" or attr.startswith("obj"):
                continue
            s_attrs += f"{attr}={getattr(self,attr,None)} "

        return f"<{self.__class__.__name__} ({s_attrs})>"

    def __getattribute__(self, item: str):
        if item.startswith("__"):
            return super().__getattribute__(item)

        if item in (
            "driver",
            "update",
            "_origin_class",
            "_attrs",
            "_find_element",
        ):
            return super().__getattribute__(item)

        if item in self._attrs:
            return super().__getattribute__(item)

        if not hasattr(self.__class__._origin_class, item):
            raise AttributeError(
                f"The attribute does not exist :{item} in {self.__class__._origin_class}"
            )
        else:

            ele = self._find_element()
            return getattr(ele, item)

    def update(self, **kwargs):
        for k, v in kwargs.items():
            if all(
                [
                    k in self.__class__._attrs + ("driver",),
                    getattr(self, k, None) is None,
                ]
            ):
                setattr(self, k, v)
                logger.debug(f"Updated  {k=}, {v=}")
            else:
                logger.warning(f"Update ignored {k=}, {v=}")

    def _find_element(self):
        raise NotImplementedError


class LazyElement(BaseLazy, WebElement):
    obj: Optional[WebElement] = None
    _origin_class = WebElement
    _attrs = (
        "obj",
        "by",
        "value",
        "check_on_init",
        "time_out",
        "poll",
    )

    def __init__(
        self,
        by,
        value,
        check_on_init=True,
        time_out=None,
        poll=None,
    ):
        self.by = by
        self.value = value
        self.check_on_init = check_on_init
        self.time_out = time_out
        self.poll = poll

    def _find_element(self):
        try:
            if self.obj:
                self.obj.text
        except StaleElementReferenceException:
            logger.warning("Interaction failed, retrying", exc_info=True)
            self.obj = None

        if self.obj is None:
            logger.info(f"finding: {self}")
            try:
                obj = WebDriverWait(self.driver, self.time_out, self.poll).until(
                    lambda _: self.driver.find_element(self.by, self.value)
                )
            except TimeoutException:
                msg = f"元素定位失败（等待超时）: {self}"
                logger.error(msg, exc_info=True)
                raise ValueError(msg) from None

            self.obj = obj

            logger.info(f"found:  {self.obj.tag_name} {self.obj.rect}")
        return self.obj


class LazyElementList(BaseLazy, list):
    obj_list: Optional[List[WebElement]] = None
    _origin_class = list

    _attrs = (
        "obj_list",
        "by",
        "value",
        "check_on_init",
        "time_out",
        "poll",
    )

    def __init__(
        self,
        by,
        value,
        check_on_init=False,
        time_out=None,
        poll=None,
    ):
        self.by = by
        self.value = value
        self.check_on_init = check_on_init
        self.time_out = time_out
        self.poll = poll

    def __len__(self):
        self._find_element()
        return len(self.obj_list)

    def __getitem__(self, index):
        return self._find_element(index)

    def _find_element(self, index=0):
        def f(_):
            logger.debug(f"{time.time() }, 开始等待...")
            el_list = self.driver.find_elements(self.by, self.value)

            logger.debug(f"{time.time() },找到元素...")
            if len(el_list) <= index:
                logger.info(f"元素定位成功，但是数量不足: {len(el_list)} <= {index}")
                return False

            return el_list

        try:
            if self.obj_list:
                self.obj_list[index].text
        except StaleElementReferenceException:
            logger.warning("Interaction failed, retrying", exc_info=True)
            self.obj_list = None

        if self.obj_list is None:
            logger.info(f"finding: {self}")
            obj_list = WebDriverWait(
                self.driver,
                self.time_out,
                self.poll,
            ).until(f)

            self.obj_list = obj_list
            obj = self.obj_list[index]

            logger.info(f"found:  element count {len(self.obj_list)}")
            logger.info(f"found:  {obj.tag_name} ,{obj.rect}")

        return self.obj_list[index]


class LazyAlert(BaseLazy, Alert):
    _attrs = (
        "check_on_init",
        "time_out",
        "poll",
    )

    _origin_class = Alert

    def __init__(self, check_on_init=False, time_out=None, poll=None):
        self.check_on_init = check_on_init
        self.time_out = time_out
        self.poll = poll

    def _find_element(self):
        alert = WebDriverWait(self.driver, self.time_out, self.poll).until(
            lambda _: self.driver.switch_to.alert
        )

        return alert


class BasePage:
    url = ""
    time_out = 5
    poll = 0.5

    def __init__(self, driver: WebDriver):
        logger.info(f"Page Init : {self.__class__.__name__}")
        self.driver = driver
        self.wait = WebDriverWait(driver, self.time_out, self.poll)
        self._check_elements()

    def _check_elements(self):
        for k in dir(self):
            if k.startswith("__"):
                continue

            attr = getattr(self, k)
            if isinstance(attr, BaseLazy):
                attr.update(
                    driver=self.driver,
                    time_out=self.time_out,
                    poll=self.poll,
                )

                if attr.check_on_init:
                    logger.debug(f"check: {attr.text}")

    def _wait_interactive(self, ele: WebElement):

        self.wait.until(
            lambda _: all(
                [
                    ele.is_displayed(),
                    ele.is_enabled(),
                    ele.get_attribute("readonly") in (False, None),
                ]
            )
        )

    def send_keys(
        self,
        ele: LazyElement,
        content="",
        clear=True,
        by_js=False,
    ):

        self._wait_interactive(ele)

        if clear:
            ele.clear()
        if content:
            ele.send_keys(content)

    def click(self, ele: LazyElement, by_js=False):
        self._wait_interactive(ele)

        ele.click()

    def upload(self, ele: LazyElement, file_path, drop=False):
        self._wait_interactive(ele)

        path = Path(file_path)
        if not path.exists():
            logger.warning("文件不存在")

        ele.send_keys(str(path.absolute()))

    def wait_url_chenge(self):
        url = self.driver.current_url
        self.wait.until(url_changes(url))
